
function run() {
  // 获取代码输入框和控制台输出框
  var code = document.getElementById("code").value;
  var consoleOutput = document.getElementById("console");
  var resultOutput = document.getElementById("result");
  // 清空控制台输出框
  consoleOutput.innerHTML = "";
  // 运行代码并获取结果
  try {
    var result = eval(code);
    resultOutput.innerHTML = result;
  } catch (error) {
    consoleOutput.innerHTML = error;
  }
}
